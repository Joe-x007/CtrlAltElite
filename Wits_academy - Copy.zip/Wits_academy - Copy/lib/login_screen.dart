import 'package:flutter/material.dart';
import 'package:wits_academy/routes.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:wits_academy/firebase.dart';
import 'package:shared_preferences/shared_preferences.dart';


class Login extends StatefulWidget{
  @override
  _LoginViewState createState() => _LoginViewState();
}

class _LoginViewState extends State<Login>{
  final _formkey = GlobalKey<FormState>();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  bool isSubmitting = false;

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);













    final logo = Image.asset("assets/logo.png");

    final emailField = TextFormField(

        controller: _emailController,
      keyboardType: TextInputType.emailAddress,
      style: TextStyle(
        color: Colors.white,
      ),
      cursorColor: Colors.white,
      decoration: InputDecoration(
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.white),
        ),
        hintText: "something@example.com",
        labelText: "Email",
        labelStyle: Theme.of(context).textTheme.caption?.copyWith(color: Colors.white),
        hintStyle: TextStyle(
        color: Colors.white,
        ),
      ),
    );

    final passwordField =Column(
      children: <Widget>[
     TextFormField(
      obscureText: true,
      controller: _passwordController,
      keyboardType: TextInputType.emailAddress,
      style: TextStyle(
        color: Colors.white,
      ),
       cursorColor: Colors.white,
      decoration: InputDecoration(
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.white),
        ),
        hintText: "password",
        labelText: "Password",
        labelStyle: Theme.of(context).textTheme.caption?.copyWith(color: Colors.white),
        hintStyle: TextStyle(
          color: Colors.white,
        ),
      ),
    ),
        Padding(
            padding: EdgeInsets.all(2.0)
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            MaterialButton(
              child: Text(
                "Forgot password",
                style: Theme.of(context).textTheme.caption?.copyWith(color: Colors.white),
              ),
              onPressed: (){
                //TODO create forgot password
                //showAlertDialog(context);
              },
            ),
          ],
        ),
      ],
    );


    final fields = Padding(
      padding: EdgeInsets.only(top: 10.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          emailField,
          passwordField,
        ],

      ),
    );

    final loginButton = Material(
      elevation: 5.0,
      borderRadius: BorderRadius.circular(25.0),
      color: Colors.white,
      child: MaterialButton(

        minWidth: mq.size.width/1.2,
        padding: EdgeInsets.fromLTRB(10.0, 15.0, 10.0, 15.0),
        child: Text(
          "Login",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize:  20.0,color: Colors.black, fontWeight:  FontWeight.bold,),

        ),
        onPressed: ()  async{
          try{

            await Firebase.initializeApp();
            UserCredential user =
            await FirebaseAuth.instance.signInWithEmailAndPassword(
                email: _emailController.text,
                password: _passwordController.text);

            SharedPreferences prefs = await SharedPreferences.getInstance();
            prefs.setString('displayName', user.user!.displayName.toString());
            Navigator.of(context).pushNamed(AppRoutes.menu);

          } on FirebaseAuthException catch (e) {
            if (e.code == 'weak-password') {
              print('The password provided is too weak.');
            } else if (e.code == 'email-already-in-use') {
              print('The account already exists for that email.');
            }

          } catch (e) {
            print(e);
            _emailController.text = "";
            _passwordController.text = "";
            // TODO: AlertDialog with error
          }

        },
      ),

    );

    final bottom= Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        loginButton,
        Padding(
            padding: EdgeInsets.all(8.0),
        ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children: <Widget>[
             Text(
               "Not a member?",
               style: Theme.of(context).textTheme.subtitle1?.copyWith(color: Colors.white),
             ),
             MaterialButton(
               onPressed: (){
                Navigator.of(context).pushNamed(AppRoutes.authRegister);
               },

                 child: Text(
                   "Sign Up",
                   style: Theme.of(context).textTheme.subtitle1?.copyWith(color: Colors.white , decoration: TextDecoration.underline),
                 ),

             ),
           ],
          ),
      ],
    );


    return Scaffold(
      backgroundColor: Color(0xFF039BE5),
      body: Form(
        key: _formkey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(36.0),
          child: Container(
            height: mq.size.height,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                logo,
                fields,
                Padding(
                    padding: EdgeInsets.only(bottom: 120),
                    child: bottom,
                ),
              ],
            ),
          ),

        ),
        
      ),
    );

  }
}
package com.example.wits_academy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
